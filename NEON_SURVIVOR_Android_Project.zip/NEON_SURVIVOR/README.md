# NEON SURVIVOR

A lightweight native Kotlin / Android Canvas arcade survival game.

## Build

- Android Studio with JDK 17
- Android SDK Platform 36 and Build Tools installed
- Gradle 8.13 (the CI workflow installs this version; Android Studio can sync the project directly)

Open the project in Android Studio with Gradle 8.13 available, or run `gradle assembleDebug`. The repository includes the wrapper distribution properties; if your IDE requires the wrapper launcher files, generate them once with `gradle wrapper --gradle-version 8.13`.

## AdMob configuration

The Android App ID is configured in `app/src/main/AndroidManifest.xml`. Debug builds use Google's official rewarded test unit. Release builds use the supplied production rewarded unit via `BuildConfig.REWARDED_AD_UNIT_ID`. Do not click live ads or test with production ads. Before release, the adult AdMob account owner must complete publisher verification and app review. Add and configure Google UMP consent handling for the regions you distribute to, and complete the applicable privacy/data-safety disclosures. This starter project does not yet include a UMP consent screen.

Reward types are granted only inside the Google Mobile Ads `OnUserEarnedRewardListener`. Dismissal and failed display callbacks never grant a reward. Ads are optional; the game loop and local economy work offline.

## Gameplay

Drag anywhere in the playfield to steer. Tap the pause control at the upper-right. Avoid asteroids, collect gold orbs, and survive for a higher score. The hangar unlocks two additional ships with earned in-game coins.

## Notes

- Minimum Android API: 24
- Target SDK: 35
- No game engine, WebView, analytics SDK, or external game assets
- Local progress is stored in SharedPreferences
- Debug and release ad-unit selection is controlled by Gradle build type
