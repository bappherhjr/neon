package com.thedev.neonsurvivor.ui

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.thedev.neonsurvivor.ads.AdMobManager
import com.thedev.neonsurvivor.ads.RewardType
import com.thedev.neonsurvivor.data.GameStore
import com.thedev.neonsurvivor.game.*
import kotlin.math.*
import kotlin.random.Random

private enum class Screen { SPLASH, MENU, PLAYING, PAUSED, GAME_OVER, SETTINGS, SHIPS, STATS }

class GameView(context: Context, private val store: GameStore, private val sound: SoundManager, private val ads: AdMobManager) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val obstacles = ObstacleManager()
    private val score = ScoreManager()
    private var screen = Screen.SPLASH
    private val splashStarted = SystemClock.elapsedRealtime()
    private var lastFrame = 0L
    private var playerX = 0f; private var playerY = 0f; private var targetX = 0f; private var targetY = 0f
    private var shield = false; private var shieldTime = 0f
    private var secondChanceUsed = false; private var doubleCoinsClaimed = false; private var runSaved = false
    private var finalScore = 0; private var finalCoins = 0; private var finalSeconds = 0
    private var adStatus = ""
    private var dragging = false
    private val stars = ArrayList<FloatArray>()
    private val cyan = Color.rgb(0,229,255); private val purple = Color.rgb(173,80,255); private val blue = Color.rgb(45,112,255)
    private val ships = listOf("NOVA" to 0, "PHANTOM" to 350, "PULSE" to 700)
    private val shipColors = intArrayOf(cyan, purple, Color.rgb(255,80,190))

    init { isFocusable = true; repeat(65) { stars.add(floatArrayOf(Random.nextFloat(),Random.nextFloat(),1f+Random.nextFloat()*2f)) } }
    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER, bold: Boolean = false) {
        p.reset(); p.isAntiAlias=true; p.color=color; p.textSize=size; p.textAlign=align; p.typeface=if(bold) Typeface.create("sans-serif",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL); c.drawText(s,x,y,p)
    }
    private fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int) { p.reset(); p.isAntiAlias=true; p.color=color; p.alpha=75; p.maskFilter=BlurMaskFilter(r*.9f,BlurMaskFilter.Blur.NORMAL); c.drawCircle(x,y,r,p); p.maskFilter=null; p.alpha=255; c.drawCircle(x,y,r*.38f,p) }
    private fun button(c: Canvas, label: String, x: Float, y: Float, w: Float, h: Float, color: Int=cyan, sub: String?=null) {
        p.reset(); p.isAntiAlias=true; p.style=Paint.Style.STROKE; p.strokeWidth=2f; p.color=color; p.alpha=220; c.drawRoundRect(x-w/2,y-h/2,x+w/2,y+h/2,18f,18f,p)
        p.style=Paint.Style.FILL; p.color=color; p.alpha=22; c.drawRoundRect(x-w/2,y-h/2,x+w/2,y+h/2,18f,18f,p)
        text(c,label,x,y+6f,17f,Color.WHITE,bold=true); if(sub!=null) text(c,sub,x,y+h/2+20f,10f,0xff9da8c7)
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); val w=width.toFloat(); val h=height.toFloat(); if(w<=0||h<=0)return
        canvas.drawColor(0xff050510)
        p.reset(); p.isAntiAlias=true; p.shader=RadialGradient(w*.5f,h*.35f,w*.8f,intArrayOf(0xff11132c,0xff050510),null,Shader.TileMode.CLAMP); canvas.drawRect(0f,0f,w,h,p); p.shader=null
        stars.forEach { it[1]+= if(screen==Screen.PLAYING) .0018f else .00035f; if(it[1]>1f)it[1]=0f; p.color=0xff65739d; p.alpha=if(it[2]>2f)170 else 85; canvas.drawCircle(it[0]*w,it[1]*h,it[2],p) }
        if (screen == Screen.SPLASH && SystemClock.elapsedRealtime() - splashStarted > 1250L) screen = Screen.MENU
        when(screen) {
            Screen.SPLASH -> drawSplash(canvas,w,h)
            Screen.MENU -> drawMenu(canvas,w,h)
            Screen.PLAYING -> { updateGame(); drawGame(canvas,w,h) }
            Screen.PAUSED -> { drawGame(canvas,w,h); overlay(canvas,w,h,"PAUSED"); button(canvas,"RESUME",w/2,h*.53f,w*.62f,54f); button(canvas,"QUIT RUN",w/2,h*.64f,w*.62f,48f,purple) }
            Screen.GAME_OVER -> drawGameOver(canvas,w,h)
            Screen.SETTINGS -> drawSettings(canvas,w,h)
            Screen.SHIPS -> drawShips(canvas,w,h)
            Screen.STATS -> drawStats(canvas,w,h)
        }
        postInvalidateOnAnimation()
    }
    private fun drawSplash(c:Canvas,w:Float,h:Float) {
        text(c,"NEON",w/2,h*.44f,54f,cyan,bold=true); text(c,"SURVIVOR",w/2,h*.51f,28f,Color.WHITE,bold=true); text(c,"PREPARE FOR THE VOID",w/2,h*.57f,10f,0xff8c9bbd)
        glow(c,w/2,h*.68f,20f,cyan)
    }
    private fun drawMenu(c:Canvas,w:Float,h:Float) {
        text(c,"NEON",w/2,h*.20f,52f,cyan,bold=true); text(c,"SURVIVOR",w/2,h*.27f,27f,Color.WHITE,bold=true); text(c,"ENDLESS SPACE • SURVIVE THE VOID",w/2,h*.32f,10f,0xff8c9bbd)
        drawShip(c,w/2,h*.43f,1.35f,shipColors[store.selectedShip.coerceIn(0,2)])
        text(c,"BEST  ${store.highScore}",w/2,h*.52f,14f,0xffb9c6e8,bold=true); text(c,"COINS  ${store.coins}",w/2,h*.56f,13f,0xffffd76a)
        button(c,"PLAY",w/2,h*.66f,w*.68f,58f); button(c,"SHIP HANGAR",w/2,h*.76f,w*.68f,46f,purple); button(c,"STATS",w*.30f,h*.86f,w*.36f,42f,blue); button(c,"SETTINGS",w*.70f,h*.86f,w*.36f,42f,blue)
        button(c,"FREE SHIELD • AD",w/2,h*.94f,w*.68f,38f,0xffffd76a)
    }
    private fun drawGame(c:Canvas,w:Float,h:Float) {
        text(c,"SCORE  ${score.score}",18f,34f,16f,Color.WHITE,Paint.Align.LEFT,true); text(c,"COINS ${score.runCoins}",w-18f,34f,14f,0xffffd76a,Paint.Align.RIGHT,true)
        obstacles.obstacles.forEach { b -> p.reset(); p.isAntiAlias=true; p.color=if(b.kind==1)purple else 0xff8a94b8; p.style=Paint.Style.STROKE; p.strokeWidth=2.5f; c.save(); c.rotate(b.rotation,b.x,b.y); c.drawCircle(b.x,b.y,b.radius,p); c.drawLine(b.x-b.radius*.6f,b.y-b.radius*.4f,b.x+b.radius*.6f,b.y+b.radius*.4f,p); c.drawLine(b.x+b.radius*.5f,b.y-b.radius*.6f,b.x-b.radius*.3f,b.y+b.radius*.6f,p); c.restore() }
        obstacles.pickups.forEach { glow(c,it.x,it.y,it.radius,0xffffd34d) }
        if(shield) { p.reset(); p.isAntiAlias=true; p.style=Paint.Style.STROKE; p.strokeWidth=3f; p.color=cyan; p.alpha=170; c.drawCircle(playerX,playerY,34f,p) }
        drawShip(c,playerX,playerY,1f,shipColors[store.selectedShip.coerceIn(0,2)])
        button(c,"Ⅱ",w-34f, h*.10f,48f,42f,purple)
        if(shield) text(c,"SHIELD ${shieldTime.toInt()}s",w/2,60f,11f,cyan)
    }
    private fun drawShip(c:Canvas,x:Float,y:Float,scale:Float,color:Int) {
        glow(c,x,y+5f,17f*scale,color); p.reset(); p.isAntiAlias=true; p.color=color; p.style=Paint.Style.FILL
        val path=Path().apply { moveTo(x,y-23f*scale); lineTo(x+16f*scale,y+17f*scale); lineTo(x,y+10f*scale); lineTo(x-16f*scale,y+17f*scale); close() }; c.drawPath(path,p)
        p.color=Color.WHITE; c.drawCircle(x,y,3.5f*scale,p)
    }
    private fun updateGame() {
        val now=SystemClock.elapsedRealtime(); if(lastFrame==0L)lastFrame=now; val dt=((now-lastFrame)/1000f).coerceIn(0f,.035f); lastFrame=now
        if(screen!=Screen.PLAYING)return
        score.update(dt); val difficulty=score.elapsed/8f
        obstacles.update(dt,width.toFloat(),height.toFloat(),difficulty)
        playerX += (targetX-playerX)*min(1f,dt*12f); playerY += (targetY-playerY)*min(1f,dt*12f)
        val got=obstacles.collect(playerX,playerY,13f); repeat(got){score.collectCoin();sound.coin()}
        if(shield){shieldTime-=dt;if(shieldTime<=0f)shield=false}
        if(obstacles.collides(playerX,playerY,12f)) { if(shield){shield=false; obstacles.obstacles.clear()} else endRun() }
    }
    private fun overlay(c:Canvas,w:Float,h:Float,title:String) { p.color=0xdd050510; c.drawRect(0f,0f,w,h,p); text(c,title,w/2,h*.40f,34f,cyan,bold=true) }
    private fun drawGameOver(c:Canvas,w:Float,h:Float) {
        overlay(c,w,h,"RUN OVER"); text(c,"SCORE  $finalScore",w/2,h*.47f,22f,Color.WHITE,bold=true); text(c,"COINS  $finalCoins",w/2,h*.51f,15f,0xffffd76a)
        if(!secondChanceUsed) button(c,"WATCH AD • SECOND CHANCE",w/2,h*.60f,w*.82f,48f,cyan) else text(c,"SECOND CHANCE USED",w/2,h*.60f,11f,0xff8793b3)
        if(!doubleCoinsClaimed && finalCoins>0) button(c,"DOUBLE COINS • AD",w/2,h*.69f,w*.82f,46f,purple)
        button(c,"RUN AGAIN",w/2,h*.79f,w*.62f,46f,blue); button(c,"MAIN MENU",w/2,h*.88f,w*.62f,42f,blue)
        if(adStatus.isNotBlank()) text(c,adStatus,w/2,h*.95f,11f,0xffaab5d0)
    }
    private fun drawSettings(c:Canvas,w:Float,h:Float) { text(c,"SETTINGS",w/2,h*.22f,30f,cyan,bold=true); button(c,"SOUND  ${if(store.soundEnabled)"ON" else "OFF"}",w/2,h*.42f,w*.72f,54f); button(c,"VIBRATION  ${if(store.vibrationEnabled)"ON" else "OFF"}",w/2,h*.54f,w*.72f,54f,purple); button(c,"BACK",w/2,h*.78f,w*.55f,48f) }
    private fun drawShips(c:Canvas,w:Float,h:Float) { text(c,"SHIP HANGAR",w/2,h*.20f,28f,cyan,bold=true); ships.forEachIndexed { i,pair -> val y=h*(.36f+i*.19f); drawShip(c,w/2,y-18f,.9f,shipColors[i]); val owned=store.isShipOwned(i); text(c,pair.first,w/2,y+28f,15f,Color.WHITE,bold=true); button(c,if(owned){if(store.selectedShip==i)"EQUIPPED" else "EQUIP"} else "BUY  ${pair.second}",w/2,y+70f,w*.55f,38f,if(i==1)purple else cyan) }; button(c,"BACK",w/2,h*.91f,w*.5f,42f) }
    private fun drawStats(c:Canvas,w:Float,h:Float) { text(c,"FLIGHT RECORD",w/2,h*.22f,27f,cyan,bold=true); text(c,"HIGH SCORE     ${store.highScore}",w/2,h*.40f,18f,Color.WHITE); text(c,"TOTAL RUNS     ${store.totalRuns}",w/2,h*.49f,18f,Color.WHITE); text(c,"TOTAL COINS    ${store.totalCoins}",w/2,h*.58f,18f,0xffffd76a); text(c,"BEST SURVIVAL  ${store.bestTime}s",w/2,h*.67f,18f,Color.WHITE); text(c,"FIRST FLIGHT ${if(store.totalRuns>0)"✓" else "—"}   SURVIVOR ${if(store.bestTime>=60)"✓" else "—"}",w/2,h*.74f,11f,purple); text(c,"ACE PILOT ${if(store.highScore>=1000)"✓" else "—"}",w/2,h*.78f,11f,purple); text(c,"DAILY: SURVIVE 45s • +50 COINS",w/2,h*.82f,10f,0xffffd76a); button(c,"BACK",w/2,h*.88f,w*.55f,46f) }
    private fun startRun() { score.reset(); obstacles.clear(); secondChanceUsed=false; doubleCoinsClaimed=false; runSaved=false; savedRunCoins=0; shieldTime=if(shield)12f else 0f; playerX=width/2f; playerY=height*.78f; targetX=playerX; targetY=playerY; screen=Screen.PLAYING; lastFrame=SystemClock.elapsedRealtime(); adStatus="" }
    private fun endRun() { if(screen!=Screen.PLAYING)return; screen=Screen.GAME_OVER; sound.crash(); finalScore=score.score; finalCoins=score.runCoins; finalSeconds=score.elapsed.toInt(); if(!runSaved){store.finishRun(finalScore,finalSeconds);runSaved=true}else{store.updateRecord(finalScore,finalSeconds)};if(finalCoins>savedRunCoins){store.addCoins(finalCoins-savedRunCoins);savedRunCoins=finalCoins};val day=SimpleDateFormat("yyyyMMdd", Locale.US).format(Date());if(finalSeconds>=45&&store.claimDailyChallenge(day)){store.addCoins(50);adStatus="Daily challenge complete: +50 coins"} }
    fun onRewardEarned(type:RewardType) { when(type) { RewardType.SECOND_CHANCE -> if(screen==Screen.GAME_OVER&&!secondChanceUsed){secondChanceUsed=true;shield=true;shieldTime=4f;screen=Screen.PLAYING;lastFrame=SystemClock.elapsedRealtime();adStatus=""} ; RewardType.DOUBLE_COINS -> if(screen==Screen.GAME_OVER&&!doubleCoinsClaimed){doubleCoinsClaimed=true;store.addCoins(score.runCoins);finalCoins=score.runCoins*2;adStatus="Run coins doubled!"} ; RewardType.TEMP_SHIELD -> {shield=true;shieldTime=12f;adStatus="Shield activated for next run"} }; invalidate() }
    fun setAdStatus(status:String){adStatus=status;invalidate()}
    fun pauseForLifecycle(){if(screen==Screen.PLAYING)screen=Screen.PAUSED;lastFrame=0L}
    fun resumeFromLifecycle(){lastFrame=SystemClock.elapsedRealtime();invalidate()}
    fun handleBack(){when(screen){Screen.PLAYING->screen=Screen.PAUSED;Screen.PAUSED->screen=Screen.PLAYING;Screen.MENU,Screen.SPLASH->{};else->screen=Screen.MENU};invalidate()}
    override fun onTouchEvent(e:MotionEvent):Boolean { val x=e.x;val y=e.y;val w=width.toFloat();val h=height.toFloat(); when(e.action){MotionEvent.ACTION_DOWN,MotionEvent.ACTION_MOVE->{if(screen==Screen.PLAYING&&e.action==MotionEvent.ACTION_MOVE){targetX=x.coerceIn(20f,w-20f);targetY=y.coerceIn(h*.35f,h-35f);dragging=true};return true};MotionEvent.ACTION_UP->{if(screen==Screen.PLAYING){if(y<h*.17f&&x>w*.78f){screen=Screen.PAUSED}else{targetX=x.coerceIn(20f,w-20f);targetY=y.coerceIn(h*.35f,h-35f)};dragging=false;invalidate();return true}
        when(screen){Screen.MENU->when{y>h*.61f&&y<h*.71f->startRun();y>h*.72f&&y<h*.81f->screen=Screen.SHIPS;y>h*.82f&&x<w*.49f->screen=Screen.STATS;y>h*.82f&&x>=w*.49f&&y<h*.91f->screen=Screen.SETTINGS;y>h*.90f->{ads.show(RewardType.TEMP_SHIELD)}}
        Screen.PAUSED->when{y in h*.48f..h*.59f->screen=Screen.PLAYING;y in h*.60f..h*.70f->{screen=Screen.MENU}}
        Screen.GAME_OVER->when{y in h*.56f..h*.65f&&!secondChanceUsed->{ads.show(RewardType.SECOND_CHANCE)};y in h*.65f..h*.74f&&!doubleCoinsClaimed&&finalCoins>0->{ads.show(RewardType.DOUBLE_COINS)};y in h*.75f..h*.84f->startRun();y>h*.84f->screen=Screen.MENU}
        Screen.SETTINGS->when{y in h*.35f..h*.49f->store.soundEnabled=!store.soundEnabled;y in h*.49f..h*.62f->store.vibrationEnabled=!store.vibrationEnabled;y>h*.70f->screen=Screen.MENU}
        Screen.SHIPS-> {val idx=((y/h-.29f)/.19f).roundToInt();if(idx in 0..2&&y<h*.83f){if(store.isShipOwned(idx)){store.selectedShip=idx}else if(store.spendCoins(ships[idx].second)){store.ownShip(idx);store.selectedShip=idx}}else if(y>h*.86f)screen=Screen.MENU}
        Screen.STATS->if(y>h*.80f)screen=Screen.MENU
        else->{} };sound.click();invalidate();return true};};return true }
}
