package com.thedev.neonsurvivor

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import com.thedev.neonsurvivor.ads.AdMobManager
import com.thedev.neonsurvivor.ads.RewardType
import com.thedev.neonsurvivor.data.GameStore
import com.thedev.neonsurvivor.game.SoundManager
import com.thedev.neonsurvivor.ui.GameView

class MainActivity : Activity() {
    private lateinit var store: GameStore
    private lateinit var sound: SoundManager
    private lateinit var ads: AdMobManager
    private lateinit var gameView: GameView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        store = GameStore(this)
        sound = SoundManager(this, { store.soundEnabled }, { store.vibrationEnabled })
        ads = AdMobManager(this, { reward -> if (::gameView.isInitialized) gameView.onRewardEarned(reward) }, { status -> if (::gameView.isInitialized) gameView.setAdStatus(status) })
        gameView = GameView(this, store, sound, ads)
        setContentView(gameView)
        ads.initialize()
    }
    override fun onPause() { super.onPause(); if (::gameView.isInitialized) gameView.pauseForLifecycle() }
    override fun onResume() { super.onResume(); if (::gameView.isInitialized) gameView.resumeFromLifecycle() }
    override fun onDestroy() { if (::sound.isInitialized) sound.release(); if (::ads.isInitialized) ads.destroy(); super.onDestroy() }
    @Deprecated("Deprecated in Android")
    override fun onBackPressed() { if (::gameView.isInitialized) gameView.handleBack() else super.onBackPressed() }
}
