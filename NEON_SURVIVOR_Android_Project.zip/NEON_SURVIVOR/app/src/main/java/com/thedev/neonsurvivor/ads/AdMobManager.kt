package com.thedev.neonsurvivor.ads

import android.app.Activity
import android.util.Log
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.thedev.neonsurvivor.BuildConfig

enum class RewardType { SECOND_CHANCE, DOUBLE_COINS, TEMP_SHIELD }

class AdMobManager(private val activity: Activity, private val onReward: (RewardType) -> Unit, private val onStatus: (String) -> Unit) {
    private var rewardedAd: RewardedAd? = null
    private var loading = false
    private var showing = false
    private var pending: RewardType? = null

    fun initialize() {
        MobileAds.initialize(activity) {
            activity.runOnUiThread { loadRewarded() }
        }
    }

    fun loadRewarded() {
        if (loading || rewardedAd != null || showing) return
        loading = true
        RewardedAd.load(activity, BuildConfig.REWARDED_AD_UNIT_ID, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    loading = false
                    rewardedAd = ad
                    onStatus("Ad ready")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    loading = false
                    rewardedAd = null
                    Log.w("NeonAds", "Rewarded ad load failed: ${error.message}")
                    onStatus("Ad unavailable. Try again later.")
                }
            })
    }

    fun show(type: RewardType): Boolean {
        if (showing) return false
        val ad = rewardedAd
        if (ad == null) { onStatus(if (loading) "Loading ad…" else "No ad available right now"); loadRewarded(); return false }
        showing = true
        pending = type
        rewardedAd = null
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                showing = false
                pending = null
                if (!earned) onStatus("No reward earned")
                loadRewarded()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                showing = false
                pending = null
                onStatus("Ad could not be shown")
                loadRewarded()
            }
        }
        ad.show(activity) {
            if (!earned) {
                earned = true
                val reward = pending
                pending = null
                if (reward != null) activity.runOnUiThread { onReward(reward) }
            }
        }
        return true
    }

    fun destroy() { rewardedAd = null; pending = null; showing = false }
}
