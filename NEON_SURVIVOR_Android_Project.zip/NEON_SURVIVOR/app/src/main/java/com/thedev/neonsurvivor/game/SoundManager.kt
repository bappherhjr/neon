package com.thedev.neonsurvivor.game

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.os.Build

@Suppress("DEPRECATION")
class SoundManager(context: Context, private val enabled: () -> Boolean, private val vibration: () -> Boolean) {
    private val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 35)
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= 31) (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator else (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
    fun coin() { if (enabled()) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 55) }
    fun crash() { if (enabled()) tone.startTone(ToneGenerator.TONE_PROP_NACK, 150); if (vibration()) try { if (Build.VERSION.SDK_INT >= 26) vibrator?.vibrate(VibrationEffect.createOneShot(100, 80)) else vibrator?.vibrate(100) } catch (_: Exception) {} }
    fun click() { if (enabled()) tone.startTone(ToneGenerator.TONE_PROP_CLICK, 35) }
    fun release() { tone.release() }
}
