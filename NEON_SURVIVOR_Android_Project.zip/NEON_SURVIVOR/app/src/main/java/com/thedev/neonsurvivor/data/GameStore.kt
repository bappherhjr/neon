package com.thedev.neonsurvivor.data

import android.content.Context

class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("neon_survivor", Context.MODE_PRIVATE)
    var coins: Int get() = prefs.getInt("coins", 0); private set(v) { prefs.edit().putInt("coins", v).apply() }
    var highScore: Int get() = prefs.getInt("high_score", 0); private set(v) { prefs.edit().putInt("high_score", v).apply() }
    var bestTime: Int get() = prefs.getInt("best_time", 0); private set(v) { prefs.edit().putInt("best_time", v).apply() }
    var totalRuns: Int get() = prefs.getInt("runs", 0); private set(v) { prefs.edit().putInt("runs", v).apply() }
    var totalCoins: Int get() = prefs.getInt("total_coins", 0); private set(v) { prefs.edit().putInt("total_coins", v).apply() }
    var selectedShip: Int get() = prefs.getInt("ship", 0); set(v) { prefs.edit().putInt("ship", v).apply() }
    var soundEnabled: Boolean get() = prefs.getBoolean("sound", true); set(v) { prefs.edit().putBoolean("sound", v).apply() }
    var vibrationEnabled: Boolean get() = prefs.getBoolean("vibration", true); set(v) { prefs.edit().putBoolean("vibration", v).apply() }
    fun addCoins(amount: Int) { if (amount > 0) { coins = coins + amount; totalCoins = totalCoins + amount } }
    fun spendCoins(amount: Int): Boolean { if (amount < 0 || coins < amount) return false; coins = coins - amount; return true }
    fun finishRun(score: Int, seconds: Int) { totalRuns = totalRuns + 1; updateRecord(score, seconds) }
    fun updateRecord(score: Int, seconds: Int) { if (score > highScore) highScore = score; if (seconds > bestTime) bestTime = seconds }
    fun ownedShips(): Set<String> = prefs.getStringSet("owned_ships", setOf("0"))?.toSet() ?: setOf("0")
    fun ownShip(id: Int) { val set = ownedShips().toMutableSet(); set.add(id.toString()); prefs.edit().putStringSet("owned_ships", set).apply() }
    fun isShipOwned(id: Int) = ownedShips().contains(id.toString())
    fun claimDailyChallenge(dayKey: String): Boolean {
        if (prefs.getString("daily_claimed", "") == dayKey) return false
        prefs.edit().putString("daily_claimed", dayKey).apply()
        return true
    }
}
