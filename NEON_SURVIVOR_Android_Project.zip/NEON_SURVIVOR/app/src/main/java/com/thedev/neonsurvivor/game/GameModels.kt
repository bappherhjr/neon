package com.thedev.neonsurvivor.game

import kotlin.math.hypot
import kotlin.random.Random

data class Body(var x: Float, var y: Float, var radius: Float, var speed: Float, var kind: Int = 0, var rotation: Float = 0f)

class ObstacleManager {
    val obstacles = ArrayList<Body>()
    val pickups = ArrayList<Body>()
    private var obstacleClock = 0f
    private var coinClock = 0f
    fun update(dt: Float, width: Float, height: Float, difficulty: Float) {
        obstacleClock += dt; coinClock += dt
        val spawnEvery = (1.05f - difficulty * .035f).coerceAtLeast(.43f)
        if (obstacleClock >= spawnEvery) {
            obstacleClock = 0f
            val r = Random.nextFloat()
            val x = width * (.08f + Random.nextFloat() * .84f)
            obstacles.add(Body(x, -35f, 13f + Random.nextFloat() * 17f, 190f + difficulty * 15f, if (r > .78f) 1 else 0, Random.nextFloat() * 360f))
            if (difficulty > 8f && Random.nextFloat() > .65f) obstacles.add(Body((width-x).coerceIn(20f,width-20f), -100f, 15f, 205f+difficulty*13f))
        }
        if (coinClock >= 1.25f) { coinClock = 0f; pickups.add(Body(width*(.12f+Random.nextFloat()*.76f), -20f, 9f, 150f+difficulty*8f)) }
        obstacles.forEach { it.y += it.speed * dt; it.rotation += 90f * dt }
        pickups.forEach { it.y += it.speed * dt }
        obstacles.removeAll { it.y > height + 60f }
        pickups.removeAll { it.y > height + 30f }
    }
    fun collides(x: Float, y: Float, radius: Float): Boolean = obstacles.any { hypot(it.x-x, it.y-y) < it.radius+radius }
    fun collect(x: Float, y: Float, radius: Float): Int {
        var count = 0
        val iterator = pickups.iterator()
        while (iterator.hasNext()) { val p=iterator.next(); if (hypot(p.x-x,p.y-y) < p.radius+radius+4f) { count++; iterator.remove() } }
        return count
    }
    fun clear() { obstacles.clear(); pickups.clear(); obstacleClock=0f; coinClock=0f }
}

class ScoreManager {
    var score = 0; private set
    var runCoins = 0; private set
    var elapsed = 0f; private set
    fun update(dt: Float) { elapsed += dt; score = (elapsed * 10f).toInt() }
    fun collectCoin() { runCoins++; score += 25 }
    fun reset() { score=0; runCoins=0; elapsed=0f }
}
